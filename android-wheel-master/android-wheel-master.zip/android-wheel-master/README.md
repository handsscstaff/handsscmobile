Android-Wheel

This project initially was a mirror from this repository :
http://code.google.com/p/android-wheel/

Updates:

* Add the ability to remove shadows.
* Add the ability to color shadows.
* Add the ability to change background and foreground drawables.
* Added Holo Wheel example to the demo.



